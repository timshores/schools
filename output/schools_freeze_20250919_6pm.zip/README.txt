Snapshot frozen on 2025-09-19 22:03:25
Scope: Expenditure-per-pupil charts + ReportLab composer

Key settings (for quick rollback context):
- Palette: unified colorblind-safe (Okabe–Ito), “Other” = gray, canonical top segment
- Canonical categories (stack bottom → top): Teachers; Insurance, Retirement Programs and Other; Pupil Services; Other Teaching Services; Operations and Maintenance; Instructional Leadership; Administration; Other
- Lines: In-District (black), Out-of-District (red), white-centered markers in front of bars
- Axes: Right $/pupil unified across all pages; Left FTE unified across individual districts; Western aggregate uses proportional left axis
- Shading vs Western baseline: absolute ΔCAGR threshold = 2.0 percentage points; variable intensity by distance
- Legend/explainers: CAGR formula + shading rule rows present on district pages

Manifest (path | bytes | sha256):
- compose_pdf.py | 22187 | 2c3e4ea24dabb74a4dfca08090dd1e67561f9f05097e418d43a429f1987cb6ec
- district_expend_pp_stack.py | 5751 | d7a7479e4f68ce277b4fe3488489860904b4b442884d24b584f81ddd72f062cf
- school_shared.py | 14246 | ba26f695ef392590a4eb18500a965c5b7aba6e1b82fcf12f1e61d1c21fd8b41b